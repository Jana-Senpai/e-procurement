<?php

class App
{
 private $controller = "home"; // property controller
 private $method = "index"; // property method
 private $params = []; // property params

 public function __construct()
 {
  $url = $this->parseURL();

  // Cek apakah ada file controller
  if (file_exists("../app/controllers/" . $url[0] . ".php")) {
   $this->controller = $url[0]; //Jika ada maka ubah controller default jadi sesuai url
   unset($url[0]); // hapus array index ke nol, karena sudah dijadikan controller
  }

  // Jalankan controller sesuai property
  require_once "../app/controllers/" . $this->controller . ".php";
  $this->controller = new $this->controller(); // instansiasi class controller

  // Cek apakah ada index ke 1
  if (isset($url[1])) {
   // Jika ada, maka cek apakah itu ada di method controller
   if (method_exists($this->controller, $url[1])) {
    $this->method = $url[1];
    unset($url[1]); // hapus index ke 1 dari array karena sudah dijadikan method
   }
  }

  // Cek apakah ada masih ada didalam array
  if (!empty($url)) {
   // Jikq ada, maka jadikan parameter
   $this->params = array_values($url);
  }

  // Jika sudah ditetapkan, panggil controller, method beserta parameter jika ada
  call_user_func_array([$this->controller, $this->method], $this->params);
 }

 // method untuk merubah url jadi array
 public function parseURL()
 {
  if (isset($_GET["url"])) {
   $url = rtrim($_GET["url"], "/");
   $url = filter_var($url, FILTER_SANITIZE_URL);
   $url = explode("/", $url);
   return $url;
  }
 }
}
