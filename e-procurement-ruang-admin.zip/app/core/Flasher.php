<?php

class Flasher
{
 public static function set($type, $message)
 {
  $_SESSION["flash"] = [
   "message" => $message,
   "type" => $type,
  ];
 }

 public static function has()
 {
  return isset($_SESSION["flash"]);
 }

 public static function message()
 {
  $message = $_SESSION["flash"]["message"];
  return $message;
 }
 
 public static function type(){
  $type = $_SESSION["flash"]["type"];
  return $type;
 }
}
