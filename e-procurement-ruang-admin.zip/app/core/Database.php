<?php

class Database
{
 private $dbhost = DB_HOST;
 private $dbuser = DB_USER;
 private $dbpass = DB_PASS;
 private $dbname = DB_NAME;
 private $connect;
 private $statement;

 public function __construct()
 {
  try {
   $this->connect = new PDO(
    "mysql:host={$this->dbhost};dbname={$this->dbname}",
    $this->dbuser,
    $this->dbpass,
    [
     PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
     PDO::ATTR_EMULATE_PREPARES => false,
     PDO::ATTR_PERSISTENT => true,
    ]
   );
  } catch (PDOException $e) {
   die("Connection Failed : " . $e->getMessage());
  }
 }

 public function query($query)
 {
  $this->statement = $this->connect->prepare($query);
 }

 // Binding agar tidak terkena SQL Injection
 public function bind($param, $value, $type = null)
 {
  if (is_null($type)) {
   switch (true) {
    case is_int($value):
     $type = PDO::PARAM_INT;
     break;
    case is_bool($value):
     $type = PDO::PARAM_BOOL;
     break;
    case is_null($value):
     $type = PDO::PARAM_NULL;
     break;
    default:
     $type = PDO::PARAM_STR;
   }
  }

  $this->statement->bindValue($param, $value, $type);
 }

 public function execute()
 {
  return $this->statement->execute();
 }

 public function count()
 {
  return $this->statement->rowCount();
 }

 public function single()
 {
  $this->execute();
  return $this->statement->fetch(PDO::FETCH_ASSOC);
 }

 public function all()
 {
  $this->execute();
  return $this->statement->fetchAll(PDO::FETCH_ASSOC);
 }
}
