<?php

define("BASEURL", "http://10.40.13.223:8080/php/e-procurement-ruang-admin/public/");

define("DB_HOST", "127.0.0.1");
define("DB_USER", "root");
define("DB_PASS", "root");
define("DB_NAME", "db_procurement");