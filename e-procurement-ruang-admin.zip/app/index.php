<?php

require_once "../app/core/App.php";
require_once "../app/config/config.php";
