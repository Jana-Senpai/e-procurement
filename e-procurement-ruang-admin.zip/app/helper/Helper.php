<?php

class Helper
{
 public static function generateCSRFToken()
 {
  $token = bin2hex(random_bytes(32));
  $_SESSION["csrf_token"] = $token;
  return $token;
 }

 public static function validateCSRFToken($token)
 {
  if (!hash_equals($_SESSION["csrf_token"], $token)) {
   die("CSRF Token Validation Failed.");
  }
 }

 public static function encrypted($data)
 {
  return base64_encode($data);
 }

 public static function decrypted($data)
 {
  return base64_decode($data);
 }

 public static function redirect($page)
 {
  header("Location: " . BASEURL . $page);
  exit();
 }
}
