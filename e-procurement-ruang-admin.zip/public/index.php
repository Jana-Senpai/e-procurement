<?php

require_once "../app/index.php";

$app = new App;